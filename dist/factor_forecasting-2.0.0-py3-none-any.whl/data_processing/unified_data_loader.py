#!/usr/bin/env python3
"""
统一dataload器
解决项目中多个dataload器implementation不一致的问题，确保严格防止data泄漏
"""

import os
import sys
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple, Iterator
import logging
import numpy as np
import pandas as pd
import torch
from torch.utils.data import Dataset, DataLoader, IterableDataset

# 添加项目path
project_root = Path(__file__).parent.parent.parent
sys.path.insert(0, str(project_root))

from src.data_processing.quantitative_data_processor import (
    QuantitativeTimeSeriesSplitter,
    QuantitativeSequenceGenerator,
    QuantitativeDataConfig
)
from src.data_processing.adaptive_memory_manager import create_memory_manager
from src.data_processing.rolling_scaler import validate_time_series_split

logger = logging.getLogger(__name__)

class UnifiedStreamingDataset(IterableDataset):
    """
    统一的流式data集，严格防止data泄漏
    整合项目中所有正确的防泄漏特性
    """
    
    def __init__(self,
                 data_dir: str,
                 factor_columns: List[str],
                 target_columns: List[str],
                 sequence_length: int = 20,
                 prediction_horizon: int = 1,
                 data_split: str = 'train',
                 start_date: Optional[str] = None,
                 end_date: Optional[str] = None,
                 enable_validation: bool = True,
                 memory_manager=None):
        """
        initialize统一流式data集
        
        Args:
            data_dir: datadirectory
            factor_columns: 因子列名
            target_columns: target列名
            sequence_length: 序列length
            prediction_horizon: predict时间跨度（天数）
            data_split: data分割type ('train', 'val', 'test')
            start_date: begin日期
            end_date: end日期
            enable_validation: 是否enabledataverification
            memory_manager: memorymanagement器
        """
        self.data_dir = Path(data_dir)
        self.factor_columns = factor_columns
        self.target_columns = target_columns
        self.sequence_length = sequence_length
        self.prediction_horizon = prediction_horizon
        self.data_split = data_split
        self.start_date = start_date
        self.end_date = end_date
        self.enable_validation = enable_validation
        self.memory_manager = memory_manager
        
        # getfilelist
        self.data_files = self._get_data_files()
        
        # 时序verification
        if self.enable_validation:
            self._validate_temporal_integrity()
        
        logger.info(f"统一流式data集initializecomplete")
        logger.info(f"  data分割: {data_split}")
        logger.info(f"  序列length: {sequence_length}")
        logger.info(f"  predict时间跨度: {prediction_horizon}")
        logger.info(f"  时间范围: {start_date} 到 {end_date}")
        logger.info(f"  file数量: {len(self.data_files)}")

    def _get_data_files(self) -> List[Path]:
        """getdatafilelist"""
        all_files = []
        for file_path in self.data_dir.glob("*.parquet"):
            if len(file_path.stem) == 8 and file_path.stem.isdigit():
                file_date = file_path.stem
                
                # 应用日期filter
                if self.start_date and file_date < self.start_date.replace('-', ''):
                    continue
                if self.end_date and file_date > self.end_date.replace('-', ''):
                    continue
                
                all_files.append(file_path)
        
        return sorted(all_files)

    def _validate_temporal_integrity(self):
        """verification时序完整性"""
        if len(self.data_files) < 2:
            logger.warning("file数量不足，跳过时序verification")
            return
        
        # checkfile日期连续性
        dates = []
        for file_path in self.data_files:
            date_str = file_path.stem
            try:
                date_obj = datetime.strptime(date_str, "%Y%m%d")
                dates.append(date_obj)
            except ValueError:
                logger.warning(f"无效日期format: {date_str}")
        
        if len(dates) < 2:
            return
        
        # check是否有严重的日期跳跃（超过7天）
        dates.sort()
        for i in range(1, len(dates)):
            gap = (dates[i] - dates[i-1]).days
            if gap > 7:
                logger.warning(f"discover日期跳跃: {dates[i-1].strftime('%Y-%m-%d')} 到 {dates[i].strftime('%Y-%m-%d')} ({gap}天)")
        
        logger.info(f"时序verificationcomplete，data范围: {dates[0].strftime('%Y-%m-%d')} 到 {dates[-1].strftime('%Y-%m-%d')}")

    def __iter__(self) -> Iterator[Dict[str, torch.Tensor]]:
        """迭代生成sample，严格防止data泄漏"""
        for file_path in self.data_files:
            try:
                # 读取单个file
                df = pd.read_parquet(file_path)
                
                if df.empty:
                    continue
                
                # 基本datacleanup
                df = self._clean_data(df)
                
                # 生成序列（严格防止data泄漏）
                for sequence in self._generate_sequences(df, file_path):
                    yield sequence
                    
            except Exception as e:
                logger.error(f"processfile {file_path} error: {e}")
                continue

    def _clean_data(self, df: pd.DataFrame) -> pd.DataFrame:
        """cleanupdata"""
        # 确保necessary列存在
        required_cols = ['sid'] + self.factor_columns + self.target_columns
        missing_cols = [col for col in required_cols if col not in df.columns]
        if missing_cols:
            logger.warning(f"缺失列: {missing_cols}")
            return df
        
        # 移除package含NaN的行
        df = df.dropna(subset=self.factor_columns + self.target_columns)
        
        # 确保datatype
        for col in self.factor_columns + self.target_columns:
            if col in df.columns:
                df[col] = pd.to_numeric(df[col], errors='coerce')
        
        return df

    def _generate_sequences(self, df: pd.DataFrame, file_path: Path) -> Iterator[Dict[str, torch.Tensor]]:
        """
        生成序列，严格防止data泄漏
        usage项目中verification过的正确implementation
        """
        # 按股票group
        for stock_id, stock_group in df.groupby('sid'):
            stock_group = stock_group.reset_index(drop=True)
            
            # checkdata充足性
            min_required_length = self.sequence_length + self.prediction_horizon
            if len(stock_group) < min_required_length:
                continue
            
            # 生成滑动窗口序列
            max_start_idx = len(stock_group) - min_required_length
            
            for i in range(max_start_idx + 1):
                try:
                    # features序列：historydata [i : i+sequence_length]
                    feature_start = i
                    feature_end = i + self.sequence_length
                    feature_data = stock_group[self.factor_columns].iloc[feature_start:feature_end].values
                    
                    # targetdata：严格的未来data [i+sequence_length+prediction_horizon-1]
                    # 这确保了target是features序列之后的prediction_horizon天
                    target_idx = i + self.sequence_length + self.prediction_horizon - 1
                    target_data = stock_group[self.target_columns].iloc[target_idx].values
                    
                    # data质量check
                    if np.isnan(feature_data).any() or np.isnan(target_data).any():
                        continue
                    
                    # createsample
                    sample = {
                        'features': torch.FloatTensor(feature_data),
                        'targets': torch.FloatTensor(target_data),
                        'stock_id': torch.LongTensor([stock_id]),
                        'file_date': file_path.stem,
                        'sequence_start_idx': i,
                        'target_idx': target_idx
                    }
                    
                    yield sample
                    
                except Exception as e:
                    logger.error(f"生成序列error (股票{stock_id}, index{i}): {e}")
                    continue

class UnifiedDataLoaderFactory:
    """统一dataload器工厂"""
    
    def __init__(self, config: Dict[str, Any]):
        """
        initializedataload器工厂
        
        Args:
            config: configuredictionary
        """
        self.config = config
        self.data_dir = config['data_dir']
        self.factor_columns = config.get('factor_columns', [str(i) for i in range(100)])
        self.target_columns = config.get('target_columns', ['intra30m', 'nextT1d', 'ema1d'])
        self.sequence_length = config.get('sequence_length', 20)
        self.prediction_horizon = config.get('prediction_horizon', 1)
        self.batch_size = config.get('batch_size', 64)
        self.num_workers = config.get('num_workers', 4)
        
        # creatememorymanagement器
        self.memory_manager = create_memory_manager({
            'monitoring_interval': 3.0,
            'critical_threshold': 0.85,
            'warning_threshold': 0.75
        })
        
        logger.info(f"统一dataload器工厂initializecomplete")

    def create_time_split_loaders(self, 
                                 train_start: str, train_end: str,
                                 val_start: str, val_end: str,
                                 test_start: str, test_end: str) -> Tuple[DataLoader, DataLoader, DataLoader]:
        """
        create基于时间分割的dataload器
        严格防止data泄漏
        """
        # verification时间分割的合理性
        date_ranges = [
            (train_start, train_end, 'train'),
            (val_start, val_end, 'val'),
            (test_start, test_end, 'test')
        ]
        
        # 转换为日期object进行verification
        train_end_date = datetime.strptime(train_end, "%Y-%m-%d")
        val_start_date = datetime.strptime(val_start, "%Y-%m-%d")
        val_end_date = datetime.strptime(val_end, "%Y-%m-%d")
        test_start_date = datetime.strptime(test_start, "%Y-%m-%d")
        
        # verification时序完整性
        if not (train_end_date < val_start_date <= val_end_date < test_start_date):
            raise ValueError("时间分割违反时序完整性，可能导致data泄漏")
        
        logger.info(" 时间分割verification通过，无data泄漏风险")
        
        # createdata集
        train_dataset = UnifiedStreamingDataset(
            data_dir=self.data_dir,
            factor_columns=self.factor_columns,
            target_columns=self.target_columns,
            sequence_length=self.sequence_length,
            prediction_horizon=self.prediction_horizon,
            data_split='train',
            start_date=train_start,
            end_date=train_end,
            memory_manager=self.memory_manager
        )
        
        val_dataset = UnifiedStreamingDataset(
            data_dir=self.data_dir,
            factor_columns=self.factor_columns,
            target_columns=self.target_columns,
            sequence_length=self.sequence_length,
            prediction_horizon=self.prediction_horizon,
            data_split='val',
            start_date=val_start,
            end_date=val_end,
            memory_manager=self.memory_manager
        )
        
        test_dataset = UnifiedStreamingDataset(
            data_dir=self.data_dir,
            factor_columns=self.factor_columns,
            target_columns=self.target_columns,
            sequence_length=self.sequence_length,
            prediction_horizon=self.prediction_horizon,
            data_split='test',
            start_date=test_start,
            end_date=test_end,
            memory_manager=self.memory_manager
        )
        
        # createDataLoader
        train_loader = DataLoader(
            train_dataset,
            batch_size=self.batch_size,
            num_workers=0,  # IterableDataset不support多process
            pin_memory=torch.cuda.is_available(),
            drop_last=True
        )
        
        val_loader = DataLoader(
            val_dataset,
            batch_size=self.batch_size,
            num_workers=0,
            pin_memory=torch.cuda.is_available(),
            drop_last=False
        )
        
        test_loader = DataLoader(
            test_dataset,
            batch_size=self.batch_size,
            num_workers=0,
            pin_memory=torch.cuda.is_available(),
            drop_last=False
        )
        
        logger.info(f"dataload器createcomplete:")
        logger.info(f"  training期: {train_start} 到 {train_end}")
        logger.info(f"  verification期: {val_start} 到 {val_end}")
        logger.info(f"  test期: {test_start} 到 {test_end}")
        
        return train_loader, val_loader, test_loader

    def create_yearly_split_loaders(self, train_years: List[int], test_year: int) -> Tuple[DataLoader, DataLoader, DataLoader]:
        """
        create按年分割的dataload器
        用于滚动training
        """
        if not train_years or test_year in train_years:
            raise ValueError("training年份和test年份setuperror")
        
        if max(train_years) >= test_year:
            raise ValueError("test年份必须晚于所有training年份")
        
        # build日期范围
        train_start = f"{min(train_years)}-01-01"
        train_end = f"{max(train_years)}-12-31"
        
        # 从training年份中分出verification年份（usage最后一年的后半年）
        val_year = max(train_years)
        val_start = f"{val_year}-07-01"
        val_end = f"{val_year}-12-31"
        
        # adjustmenttrainingend时间
        if len(train_years) > 1:
            train_end = f"{val_year}-06-30"
        else:
            # 如果只有一年，分割该年
            train_end = f"{val_year}-06-30"
        
        test_start = f"{test_year}-01-01"
        test_end = f"{test_year}-12-31"
        
        logger.info(f"按年分割data:")
        logger.info(f"  training年份: {train_years}")
        logger.info(f"  test年份: {test_year}")
        logger.info(f"  training期: {train_start} 到 {train_end}")
        logger.info(f"  verification期: {val_start} 到 {val_end}")
        logger.info(f"  test期: {test_start} 到 {test_end}")
        
        return self.create_time_split_loaders(
            train_start, train_end,
            val_start, val_end,
            test_start, test_end
        )

    def cleanup(self):
        """cleanupresource"""
        if self.memory_manager:
            self.memory_manager.cleanup()


def create_unified_data_loaders(config: Dict[str, Any], 
                               time_split_config: Optional[Dict[str, str]] = None,
                               yearly_split_config: Optional[Dict[str, Any]] = None) -> Tuple[DataLoader, DataLoader, DataLoader]:
    """
    create统一dataload器的便捷function
    
    Args:
        config: foundationconfigure
        time_split_config: 时间分割configure {'train_start': ..., 'train_end': ..., ...}
        yearly_split_config: 年份分割configure {'train_years': [...], 'test_year': ...}
    
    Returns:
        (train_loader, val_loader, test_loader)
    """
    factory = UnifiedDataLoaderFactory(config)
    
    if time_split_config:
        return factory.create_time_split_loaders(
            time_split_config['train_start'],
            time_split_config['train_end'],
            time_split_config['val_start'],
            time_split_config['val_end'],
            time_split_config['test_start'],
            time_split_config['test_end']
        )
    elif yearly_split_config:
        return factory.create_yearly_split_loaders(
            yearly_split_config['train_years'],
            yearly_split_config['test_year']
        )
    else:
        raise ValueError("必须提供时间分割configure或年份分割configure")


# 向后compatible的工厂function
def create_leak_free_data_loaders(data_dir: str,
                                 factor_columns: List[str],
                                 target_columns: List[str],
                                 sequence_length: int = 20,
                                 prediction_horizon: int = 1,
                                 batch_size: int = 64,
                                 train_start: str = "2018-01-01",
                                 train_end: str = "2018-10-31",
                                 val_start: str = "2018-11-01", 
                                 val_end: str = "2018-12-31",
                                 test_start: str = "2019-01-01",
                                 test_end: str = "2019-03-31") -> Tuple[DataLoader, DataLoader, DataLoader]:
    """create无data泄漏的dataload器"""
    
    config = {
        'data_dir': data_dir,
        'factor_columns': factor_columns,
        'target_columns': target_columns,
        'sequence_length': sequence_length,
        'prediction_horizon': prediction_horizon,
        'batch_size': batch_size
    }
    
    time_split_config = {
        'train_start': train_start,
        'train_end': train_end,
        'val_start': val_start,
        'val_end': val_end,
        'test_start': test_start,
        'test_end': test_end
    }
    
    return create_unified_data_loaders(config, time_split_config=time_split_config)
