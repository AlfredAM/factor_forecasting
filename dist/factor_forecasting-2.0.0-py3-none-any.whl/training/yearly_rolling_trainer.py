#!/usr/bin/env python3
"""
按年滚动trainingsystem
特性7的完整implementation：data是一天一个file，需要按天连续train。每次train之前的年份，然后看下一年inference结果
"""

import os
import sys
import logging
import json
import time
from pathlib import Path
from datetime import datetime, timedelta
from typing import Dict, List, Any, Optional, Tuple
import numpy as np
import pandas as pd

import torch
import torch.nn as nn
from torch.utils.data import DataLoader

logger = logging.getLogger(__name__)

class YearlyRollingTrainer:
    """按年滚动trainingsystem"""
    
    def __init__(self, 
                 data_dir: str,
                 model_factory,
                 output_dir: str,
                 config: Dict[str, Any]):
        """
        initialize按年滚动training器
        
        Args:
            data_dir: datadirectory（package含按天的parquetfile）
            model_factory: model工厂function
            output_dir: outputdirectory
            config: trainingconfigure
        """
        self.data_dir = Path(data_dir)
        self.model_factory = model_factory
        self.output_dir = Path(output_dir)
        self.config = config
        
        # createoutputdirectory
        self.output_dir.mkdir(parents=True, exist_ok=True)
        
        # get可用data
        self.available_files = self._discover_data_files()
        self.available_years = self._get_available_years()
        
        # 滚动trainingconfigure
        self.min_train_years = config.get('min_train_years', 2)
        self.max_train_years = config.get('max_train_years', 5)
        self.prediction_start_year = config.get('prediction_start_year', None)
        
        # traininghistory
        self.training_history = []
        self.inference_results = {}
        
        logger.info(f"按年滚动training器initializecomplete")
        logger.info(f"datadirectory: {self.data_dir}")
        logger.info(f"可用年份: {self.available_years}")
        logger.info(f"可用file数量: {len(self.available_files)}")

    def _discover_data_files(self) -> List[Path]:
        """discover所有datafile"""
        files = []
        for file_path in self.data_dir.glob("*.parquet"):
            if len(file_path.stem) == 8 and file_path.stem.isdigit():
                files.append(file_path)
        
        return sorted(files)

    def _get_available_years(self) -> List[int]:
        """get可用年份"""
        years = set()
        for file_path in self.available_files:
            year = int(file_path.stem[:4])
            years.add(year)
        return sorted(list(years))

    def _get_files_for_years(self, years: List[int]) -> List[Path]:
        """get指定年份的所有file"""
        files = []
        for file_path in self.available_files:
            file_year = int(file_path.stem[:4])
            if file_year in years:
                files.append(file_path)
        return sorted(files)

    def _get_files_for_year(self, year: int) -> List[Path]:
        """get指定年份的所有file"""
        return self._get_files_for_years([year])

    def _create_datasets_for_years(self, train_years: List[int], test_year: int) -> Tuple[DataLoader, DataLoader, DataLoader]:
        """为指定年份createdata集"""
        from src.data_processing.streaming_data_loader import StreamingDataLoader, StreamingDataset
        
        # getfile
        train_files = self._get_files_for_years(train_years)
        test_files = self._get_files_for_year(test_year)
        
        # 划分training和verification集（从training年份的最后一年中分出verification集）
        if len(train_years) > 1:
            val_year = train_years[-1]
            train_years_final = train_years[:-1]
            train_files = self._get_files_for_years(train_years_final)
            val_files = self._get_files_for_year(val_year)
        else:
            # 如果只有一年trainingdata，从该年中分出80%training，20%verification
            val_files = train_files[int(len(train_files) * 0.8):]
            train_files = train_files[:int(len(train_files) * 0.8)]
        
        logger.info(f"data分割:")
        logger.info(f"  trainingfile: {len(train_files)} 个 (年份: {train_years_final if len(train_years) > 1 else train_years})")
        logger.info(f"  verificationfile: {len(val_files)} 个 (年份: {val_year if len(train_years) > 1 else '部分' + str(train_years[0])})")
        logger.info(f"  testfile: {len(test_files)} 个 (年份: {test_year})")
        
        # createdataload器
        streaming_loader = StreamingDataLoader(
            data_dir=str(self.data_dir),
            batch_size=1000,
            cache_size=5,
            max_memory_mb=4096,
            max_workers=4
        )
        
        # 因子和target列
        factor_columns = [str(i) for i in range(100)]
        target_columns = self.config.get('target_columns', ['intra30m', 'nextT1d', 'ema1d'])
        sequence_length = self.config.get('sequence_length', 20)
        batch_size = self.config.get('batch_size', 64)
        
        # createdata集
        train_dataset = StreamingDataset(
            streaming_loader=streaming_loader,
            factor_columns=factor_columns,
            target_columns=target_columns,
            sequence_length=sequence_length,
            start_date=None,
            end_date=None
        )
        
        val_dataset = StreamingDataset(
            streaming_loader=streaming_loader,
            factor_columns=factor_columns,
            target_columns=target_columns,
            sequence_length=sequence_length,
            start_date=None,
            end_date=None
        )
        
        test_dataset = StreamingDataset(
            streaming_loader=streaming_loader,
            factor_columns=factor_columns,
            target_columns=target_columns,
            sequence_length=sequence_length,
            start_date=None,
            end_date=None
        )
        
        # createDataLoader
        train_loader = DataLoader(
            train_dataset,
            batch_size=batch_size,
            num_workers=0,  # IterableDataset不support多process
            pin_memory=torch.cuda.is_available()
        )
        
        val_loader = DataLoader(
            val_dataset,
            batch_size=batch_size,
            num_workers=0,
            pin_memory=torch.cuda.is_available()
        )
        
        test_loader = DataLoader(
            test_dataset,
            batch_size=batch_size,
            num_workers=0,
            pin_memory=torch.cuda.is_available()
        )
        
        return train_loader, val_loader, test_loader

    def _train_single_window(self, train_years: List[int], test_year: int) -> Dict[str, Any]:
        """training单个时间窗口"""
        logger.info(f"begintraining窗口: {train_years} -> {test_year}")
        
        # createdata集
        train_loader, val_loader, test_loader = self._create_datasets_for_years(train_years, test_year)
        
        # createmodel
        model = self.model_factory(self.config)
        device = torch.device('cuda' if torch.cuda.is_available() else 'cpu')
        model = model.to(device)
        
        # createoptimize器
        optimizer = torch.optim.AdamW(
            model.parameters(),
            lr=self.config.get('learning_rate', 0.001),
            weight_decay=self.config.get('weight_decay', 1e-5)
        )
        
        # createlossfunction
        from src.training.quantitative_loss import QuantitativeCorrelationLoss
        loss_config = {
            'mse_weight': 0.4,
            'correlation_weight': 1.0,
            'rank_correlation_weight': 0.3,
            'risk_penalty_weight': 0.1,
            'target_correlations': [0.08, 0.05, 0.03]
        }
        criterion = QuantitativeCorrelationLoss(loss_config).to(device)
        
        # trainingconfigure
        epochs = self.config.get('epochs', 50)
        best_val_loss = float('inf')
        best_model_state = None
        training_losses = []
        val_losses = []
        
        # trainingloop
        for epoch in range(epochs):
            # training阶段
            model.train()
            train_loss = 0.0
            train_batches = 0
            
            for batch in train_loader:
                try:
                    features = batch['features'].to(device)
                    targets = batch['targets'].to(device)
                    stock_ids = batch['stock_id'].to(device)
                    
                    optimizer.zero_grad()
                    
                    predictions = model(features, stock_ids.squeeze())
                    target_dict = {col: targets[:, i] for i, col in enumerate(self.config['target_columns'])}
                    
                    loss_dict = criterion(predictions, target_dict)
                    loss = loss_dict['total_loss']
                    
                    loss.backward()
                    torch.nn.utils.clip_grad_norm_(model.parameters(), 1.0)
                    optimizer.step()
                    
                    train_loss += loss.item()
                    train_batches += 1
                    
                    if train_batches >= 100:  # 限制training批次以节省时间
                        break
                        
                except Exception as e:
                    logger.error(f"training批次error: {e}")
                    continue
            
            avg_train_loss = train_loss / max(train_batches, 1)
            training_losses.append(avg_train_loss)
            
            # verification阶段
            model.eval()
            val_loss = 0.0
            val_batches = 0
            
            with torch.no_grad():
                for batch in val_loader:
                    try:
                        features = batch['features'].to(device)
                        targets = batch['targets'].to(device)
                        stock_ids = batch['stock_id'].to(device)
                        
                        predictions = model(features, stock_ids.squeeze())
                        target_dict = {col: targets[:, i] for i, col in enumerate(self.config['target_columns'])}
                        
                        loss_dict = criterion(predictions, target_dict)
                        loss = loss_dict['total_loss']
                        
                        val_loss += loss.item()
                        val_batches += 1
                        
                        if val_batches >= 50:  # 限制verification批次
                            break
                            
                    except Exception as e:
                        logger.error(f"verification批次error: {e}")
                        continue
            
            avg_val_loss = val_loss / max(val_batches, 1)
            val_losses.append(avg_val_loss)
            
            # save最佳model
            if avg_val_loss < best_val_loss:
                best_val_loss = avg_val_loss
                best_model_state = model.state_dict().copy()
            
            if epoch % 10 == 0:
                logger.info(f"Epoch {epoch}: Train Loss: {avg_train_loss:.6f}, Val Loss: {avg_val_loss:.6f}")
        
        # load最佳model进行test
        if best_model_state:
            model.load_state_dict(best_model_state)
        
        # test阶段 - 生成predict结果
        model.eval()
        test_predictions = []
        test_targets = []
        test_stock_ids = []
        
        with torch.no_grad():
            for batch in test_loader:
                try:
                    features = batch['features'].to(device)
                    targets = batch['targets'].to(device)
                    stock_ids = batch['stock_id'].to(device)
                    
                    predictions = model(features, stock_ids.squeeze())
                    
                    # 收集predict结果
                    for col_idx, col in enumerate(self.config['target_columns']):
                        if col in predictions:
                            test_predictions.append({
                                'target': col,
                                'predictions': predictions[col].cpu().numpy(),
                                'targets': targets[:, col_idx].cpu().numpy(),
                                'stock_ids': stock_ids.cpu().numpy()
                            })
                    
                    if len(test_predictions) >= 100:  # 限制testsample数量
                        break
                        
                except Exception as e:
                    logger.error(f"test批次error: {e}")
                    continue
        
        # calculatetestmetrics
        test_metrics = self._calculate_test_metrics(test_predictions)
        
        # savemodel和结果
        window_id = f"{min(train_years)}-{max(train_years)}_{test_year}"
        model_path = self.output_dir / f"model_{window_id}.pth"
        torch.save({
            'model_state_dict': best_model_state,
            'config': self.config,
            'train_years': train_years,
            'test_year': test_year,
            'training_losses': training_losses,
            'val_losses': val_losses,
            'test_metrics': test_metrics
        }, model_path)
        
        results = {
            'window_id': window_id,
            'train_years': train_years,
            'test_year': test_year,
            'best_val_loss': best_val_loss,
            'test_metrics': test_metrics,
            'model_path': str(model_path),
            'training_losses': training_losses,
            'val_losses': val_losses
        }
        
        logger.info(f"窗口 {window_id} trainingcomplete:")
        logger.info(f"  最佳verificationloss: {best_val_loss:.6f}")
        for metric, value in test_metrics.items():
            if isinstance(value, (int, float)) and not np.isnan(value):
                logger.info(f"  {metric}: {value:.4f}")
        
        return results

    def _calculate_test_metrics(self, test_predictions: List[Dict]) -> Dict[str, float]:
        """calculatetestmetrics"""
        metrics = {}
        
        for target_col in self.config['target_columns']:
            col_predictions = []
            col_targets = []
            
            for pred_dict in test_predictions:
                if pred_dict['target'] == target_col:
                    col_predictions.extend(pred_dict['predictions'].flatten())
                    col_targets.extend(pred_dict['targets'].flatten())
            
            if len(col_predictions) > 10:
                pred_array = np.array(col_predictions)
                target_array = np.array(col_targets)
                
                # 移除NaN值
                mask = ~(np.isnan(pred_array) | np.isnan(target_array))
                if mask.sum() > 10:
                    pred_clean = pred_array[mask]
                    target_clean = target_array[mask]
                    
                    # calculatemetrics
                    ic = np.corrcoef(pred_clean, target_clean)[0, 1]
                    rank_ic = np.corrcoef(np.argsort(pred_clean), np.argsort(target_clean))[0, 1]
                    mse = np.mean((pred_clean - target_clean) ** 2)
                    
                    metrics[f'{target_col}_ic'] = ic
                    metrics[f'{target_col}_rank_ic'] = rank_ic
                    metrics[f'{target_col}_mse'] = mse
                    metrics[f'{target_col}_samples'] = len(pred_clean)
        
        return metrics

    def run_yearly_rolling_training(self) -> Dict[str, Any]:
        """run完整的按年滚动training"""
        logger.info("begin按年滚动training...")
        
        if len(self.available_years) < self.min_train_years + 1:
            raise ValueError(f"data不足，需要至少 {self.min_train_years + 1} 年data")
        
        # 确定predictbegin年份
        start_year = self.prediction_start_year or self.available_years[self.min_train_years]
        prediction_years = [year for year in self.available_years if year >= start_year]
        
        if not prediction_years:
            raise ValueError("没有可用的predict年份")
        
        logger.info(f"predict年份: {prediction_years}")
        
        all_results = {}
        
        # Execute rolling training for each prediction year
        for test_year in prediction_years:
            # Determine training years
            available_train_years = [year for year in self.available_years if year < test_year]
            
            if len(available_train_years) < self.min_train_years:
                logger.warning(f"Skipping year {test_year}: insufficient training data")
                continue
            
            # Use recent years as training data
            train_years = available_train_years[-self.max_train_years:]
            
            try:
                # Train this window
                window_results = self._train_single_window(train_years, test_year)
                all_results[test_year] = window_results
                self.training_history.append(window_results)
                
            except Exception as e:
                logger.error(f"Year {test_year} training failed: {e}")
                continue
        
        # Save overall results
        summary_file = self.output_dir / "yearly_rolling_results.json"
        with open(summary_file, 'w') as f:
            json.dump(all_results, f, indent=2, default=str)
        
        # Generate summary report
        self._generate_summary_report(all_results)
        
        logger.info(f"Yearly rolling training completed! Trained {len(all_results)} year windows")
        logger.info(f"Results saved to: {summary_file}")
        
        return all_results

    def _generate_summary_report(self, results: Dict[str, Any]):
        """Generate summary report"""
        report = {
            'summary': {
                'total_windows': len(results),
                'prediction_years': list(results.keys()),
                'avg_metrics_by_target': {}
            },
            'yearly_results': results
        }
        
        # Calculate average metrics for each target
        for target_col in self.config['target_columns']:
            ic_values = []
            rank_ic_values = []
            
            for window_results in results.values():
                metrics = window_results.get('test_metrics', {})
                ic_key = f'{target_col}_ic'
                rank_ic_key = f'{target_col}_rank_ic'
                
                if ic_key in metrics and not np.isnan(metrics[ic_key]):
                    ic_values.append(metrics[ic_key])
                if rank_ic_key in metrics and not np.isnan(metrics[rank_ic_key]):
                    rank_ic_values.append(metrics[rank_ic_key])
            
            if ic_values:
                report['summary']['avg_metrics_by_target'][target_col] = {
                    'avg_ic': np.mean(ic_values),
                    'std_ic': np.std(ic_values),
                    'avg_rank_ic': np.mean(rank_ic_values) if rank_ic_values else np.nan,
                    'num_windows': len(ic_values)
                }
        
        # Save report
        report_file = self.output_dir / "yearly_rolling_summary_report.json"
        with open(report_file, 'w') as f:
            json.dump(report, f, indent=2, default=str)
        
        # Log to logger
        logger.info("=" * 80)
        logger.info("Yearly Rolling Training Summary Report")
        logger.info("=" * 80)
        logger.info(f"Total training windows: {report['summary']['total_windows']}")
        logger.info(f"Prediction years: {report['summary']['prediction_years']}")
        
        for target_col, metrics in report['summary']['avg_metrics_by_target'].items():
            logger.info(f"{target_col}:")
            logger.info(f"  Average IC: {metrics['avg_ic']:.4f} (±{metrics['std_ic']:.4f})")
            logger.info(f"  Average Rank IC: {metrics['avg_rank_ic']:.4f}")
            logger.info(f"  Valid windows: {metrics['num_windows']}")
        
        logger.info("=" * 80)


def create_yearly_rolling_trainer(data_dir: str, model_factory, output_dir: str, config: Dict[str, Any]) -> YearlyRollingTrainer:
    """Factory function to create yearly rolling trainer"""
    return YearlyRollingTrainer(
        data_dir=data_dir,
        model_factory=model_factory,
        output_dir=output_dir,
        config=config
    )
